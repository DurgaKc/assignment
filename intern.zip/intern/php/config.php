<?php 
// $con = mysqli_connect("localhost","root","intern")

$con = mysqli_connect('localhost', 'root', '', 'intern')or die ("couldn't connect");
?>

<!-- $con = mysqli_connect("localhost", "root", "", "users");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
} -->