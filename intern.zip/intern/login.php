<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="<!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
          rel="stylesheet"
          integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
          crossorigin="anonymous"
        />
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
          integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
          crossorigin="anonymous"
          referrerpolicy="no-referrer"
        />
        <link rel="stylesheet" href="style.css" />
        <title>login Page</title>
      </head>
      <body>
             <!-- Header  -->
             <nav class="sticky-top">
                <nav class="navbar navbar-expand-lg navbar-light bg-light">
                    <div class="container-fluid">
                       
                        <a class="navbar-brand" href="index.php">Home</a>
                      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                      </button>
                      <!-- <a class="navbar-brand" href="#">Home</a>
                      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                      </button>
                      <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                          <li class="navbar-brand">
                            <a class="nav-link active" aria-current="page" href="#">Home</a>
                          </li>
                          
                        </ul> -->
                        <form class="d-flex">
                            <a class="nav-link active" aria-current="page" href="login.php">Contact Us</a>
                        </form>
                      </div>
                     
                    </div>
                  </nav>
                </nav>
                <!-- contact form -->
                 <div class="container">
                    <div class="box form-box">
                      <?php 
                    //  include("C:\xampp\htdocs\intern\login.php");
                    // $con = mysqli_connect("localhost", "root", "", "intern") 
                    // or die("Couldn't connect to database");
             
             // Correct file path for Windows
             include("C:/xampp/htdocs/intern/php/config.php");
                      if(isset($_POST['submit'])){
                        $username = $_POST['username'];
                        $email = $_POST['email'];
                        $message = $_POST['message'];

                        //verifying unique email
                        $verify_query = mysqli_query($con,"SELECT Email FROM users WHERE Email='$email");
                        if(mysqli_num_rows($verify_query) !=0){
                          echo "<div class='message'>
                          <p>Email already exists, Please try once</p>
                          </div><br>";
                          // echo"<a href='javascript:self.history.back()'><button class='button'>Save</button>";
                        }
                        else{
                          mysqli_query($con,"INSERT INTO users(Username,Email,Message) VALUES('$username','$email','$message')")or die("Error Occured");
                          echo "<div class='message'>
                          <p>Login Successfully!</p>
                          </div>";
                          echo"<a href='index.php'><button class='button'>Save</button>";
                        }
                        }else{
                      ?>
                        <form action="" method="post">
                            <div class="field input mt-4">
                                <label for="username" class="mb-1">Username</label>
                                <input type="text"  id="username" name="username" required>
                            </div>
                            <div class="field input mt-3">
                                <label for="email" class="mb-1" >Email</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                            <div class="field input mt-3">
                            <textarea rows="5" cols="30" placeholder="Enter your message here" ></textarea>
                            </div>
                            <div class="field mt-4">
                                <input type="button" class=" button text-white bg-success" value="submit">
                            </div>
                        </form>
                    </div>
                    <?php }?>
                 </div>
                <!-- contact form end!! -->

             
               <!--  Header end!! -->
                
                  <!-- footer -->
                  <div class="foot text-white">
                    <div class="d-flex justify-content-between">
                        <p class="copyright  fs-5.5 my-3 ms-2"> Copyright &copy;<a href="https://www.facebook.com/profile"
                                class="text-white mt-4 mb-4 ms-2">2025</a></p>
                        <p class="mx-3 text-white my-3">Updated on : 2081/11/10</p>
            
                    </div>
                    <!-- footer end!! -->
        <script
          src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
          integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
          crossorigin="anonymous"
        ></script>
      </body>
    </html>
    
</head>
<body>
    
</body>
</html>